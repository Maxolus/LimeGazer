# GazeCloud-plugin
 
Edited Lime Survey template in order to use the GazeCloudAPI (https://gazerecorder.com/gazecloudapi/) library to save eyetracking data from users while taking a survey.
Unfortunately, for now the demo has a time limit of 60s.

## Usage
Download the files, put them in a folder and copy it in `path-to-file...\LimeSurvey\themes\survey`

From the LimeSurvey theme editor (https://**site-name**.limesurvey.net/admin/themeoptions), press on "install". After that you can use it as a template when creating a survey.

_Todo_: save eye-tracking data retrieved by the library and generate a heatmap.

